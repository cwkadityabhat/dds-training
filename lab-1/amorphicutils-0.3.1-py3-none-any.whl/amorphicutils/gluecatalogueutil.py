# -*- coding: utf-8 -*-
"""gluecatalogueutil

This module provides utilities for AWS glue catalog on top of Amorphic

Example:
    Sample code creating a database and table on Glue
    literal blocks::

        bucket = "glue_catalog_test_bucket"
        output_location = "s3://{0}/athena/query/".format(bucket)
        glue_client = boto3.client('glue')

        print("Creating database...")
        response1 = glue_client.create_database(
            DatabaseInput={
                'Name': 'TestDatabase'
            }
        )

        print("Creating table...")
        response2 = glue_client.create_table(
            DatabaseName='TestDatabase',
            TableInput={
                'Name': 'TestTable',
                'StorageDescriptor': {
                    'Columns': [
                        {
                            'Name': 'col1',
                            'Type': 'string'
                        },
                        {
                            'Name': 'col2',
                            'Type': 'string'
                        }
                    ]
                }
            }
        )
Todo:
    * Improve the documentation
"""

# standard library imports
import time

# third party imports
import boto3


class GlueCatalogueUtil:
    """
    Class of util to query Glue
    """

    def __init__(self, s3_temp_path, region=None):
        """
        Initialize the class to query Aws Glue

        :param s3_temp_path: s3 path where query temp data is stored
        :param region:
        """
        self.s3_temp_path = s3_temp_path
        if region:
            self.region = region
            self.athena_client = boto3.client("athena", region)
        else:
            self.athena_client = boto3.client("athena")
        self.query_id = None

    def run_query(self, query):
        """
        Run the query to athena, The database name should we supplied with table name in query

        :param query:
        :return:
        """
        response = self.athena_client.start_query_execution(
            QueryString=query, ResultConfiguration={"OutputLocation": self.s3_temp_path}
        )

        if "QueryExecutionId" in response:
            self.query_id = response["QueryExecutionId"]

    def _get_query_execution_status(self):
        response = self.athena_client.get_query_execution(
            QueryExecutionId=self.query_id
        )
        return response["QueryExecution"]["Status"]["State"]

    def _wait_for_query_result(self, sleep_time, retry_count):
        """
        Wait for query to finish

        :param sleep_time: time in seconds to sleep between query result checker
        :return:
        """

        for _ in range(retry_count):
            query_status = self._get_query_execution_status()
            if query_status == "SUCCEEDED":
                return True
            if query_status in ("QUEUED", "RUNNING"):
                time.sleep(sleep_time)
            else:
                raise Exception("Athena query failed or was cancelled")
        return False

    def fetch_all(self):
        """
        Fetch all result

        :return:
        """
        query_status = self._wait_for_query_result(5, 5)
        if query_status:
            results_paginator = self.athena_client.get_paginator("get_query_results")
            results_iter = results_paginator.paginate(
                QueryExecutionId=self.query_id, PaginationConfig={"PageSize": 1000}
            )
            results = []
            data_list = []
            for results_page in results_iter:
                for row in results_page["ResultSet"]["Rows"]:
                    data_list.append(row["Data"])
            for datum in data_list[0:]:
                results.append([x["VarCharValue"] for x in datum])
            return [tuple(x) for x in results]

        return None

    def fetch_one(self):
        """
        Fetch one result

        :return:
        """
        query_status = self._wait_for_query_result(5, 5)
        if query_status:
            result = self.athena_client.get_query_results(
                QueryExecutionId=self.query_id, MaxResults=1
            )
            return result
        return None

    def __del__(self):
        self.athena_client.stop_query_execution(QueryExecutionId=self.query_id)
