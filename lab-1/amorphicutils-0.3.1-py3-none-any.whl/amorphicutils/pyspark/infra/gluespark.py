"""
Module to get spark from GlueContext
"""

import sys

try:
    from awsglue.utils import getResolvedOptions, GlueArgumentError
    from awsglue.context import GlueContext
    from awsglue.job import Job
    from pyspark.context import SparkContext
except ImportError:
    pass


class GlueSpark:
    """
    Class to get instance of spark session from aws glue
    """

    def __init__(self):
        """
        Initialize the class

        >>> glue_spark = GlueSpark()
        """
        # pylint: disable=invalid-name
        self.sc = SparkContext.getOrCreate()
        self.glue_context = GlueContext(self.sc)
        self.spark = self.glue_context.spark_session
        self.job = Job(self.glue_context)

        try:
            # @params: [JOB_NAME]
            args = getResolvedOptions(sys.argv, ["JOB_NAME"])
            self.job.init(args.get("JOB_NAME", "AmorphicGlueApp"), args)
        except GlueArgumentError as gae:
            print("JOB_NAME not available as args.")

    def get_spark(self, timezone=None):
        """
        Returns the spark session instance

        param timezone: Timezone value
        :return: SparkSession

        >>> glue_spark = GlueSpark()
        >>> spark = glue_spark.get_spark()
        """

        if timezone:
            self.spark.conf.set("spark.sql.session.timeZone", timezone)
        return self.spark

    def get_glue_context(self):
        """
        Return glue context instance
        :return: GlueContext

        >>> glue_spark = GlueSpark()
        >>> glue_context = glue_spark.get_glue_context()()
        """
        return self.glue_context

    def get_logger(self):
        """
        Return logger instance for glue
        :return: logger

        >>> glue_spark = GlueSpark()
        >>> logger = glue_spark.get_logger()()
        """
        return self.glue_context.get_logger()

    def commit_job(self):
        """
        Commit the glue job
        :return:
        """
        self.job.commit()
