"""
Helper function to create spark session
"""
import os
from pyspark.sql import SparkSession


def get_spark(app_name, master="local[*]", jar_packages=None, spark_config=None):
    """
    Returns the spark session instance
    :param app_name: application name of the spark app.
    :param master: master of the spark cluster, like local[1] or local[*]
    :param jar_packages: location of jar packages to be added to spark app
    :param spark_config: extra config for the spark app
    :return: SparkSession instance

    >>> spark = get_spark("TestApp", "local[2]")
    """

    # execution variables
    flag_debug = "DEBUG" in os.environ.keys()

    if not flag_debug:
        spark_builder = SparkSession.builder.appName(app_name)
    else:
        spark_builder = SparkSession.builder.master(master).appName(app_name)

    if jar_packages:
        spark_jars = ",".join(list(jar_packages))
        spark_builder.config("spark.jars.packages", spark_jars)

    # add extra config
    if spark_config:
        for key, value in spark_config.items():
            spark_builder.config(key, value)

    spark_session = spark_builder.getOrCreate()

    return spark_session
