"""
Write using pyspark
=================
Defines class Write, which is used to write data to amorphic datalake backed by s3.
"""

import time

import boto3
from pyspark.sql.functions import lit
from pyspark.sql import DataFrame
from awsglue.dynamicframe import DynamicFrame

try:
    from awsglue.context import GlueContext
except ImportError:
    pass

from py4j.protocol import Py4JJavaError

from amorphicutils.amorphiclogging import Log4j
from amorphicutils.common import WriteUtil, bool_retry
from amorphicutils.datalakeutil import DataLandingZoneUtil
from amorphicutils.pyspark.infra.gluespark import GlueSpark
from amorphicutils import awshelper

try:
    gs = GlueSpark()
    glue_context = gs.get_glue_context()
except TypeError as te:
    print("Java not available")


class SparkWrite(WriteUtil, DataLandingZoneUtil):
    """
    Class to write using Spark Context
    """

    def __init__(self, bucket_name, spark, region=None, logger=None):
        """
        Initialize the Write object

        :param bucket_name: Bucket name
        :param spark: SparkContext

        >>> writer = Write("lz_bucket", spark_object)
        """

        if region:
            self.s3_resource = boto3.resource("s3", region)
        else:
            self.s3_resource = boto3.resource("s3")
        self.region = region
        self.bucket = self.s3_resource.Bucket(bucket_name)
        self.bucket_name = bucket_name
        self._logger = logger if logger else Log4j(spark).get_logger()
        WriteUtil.__init__(self, bucket_name, region)
        dlz_bucket = "-".join(bucket_name.split("-")[0:-1] + ["dlz"])
        DataLandingZoneUtil.__init__(
            self, lz_bucket_name=bucket_name, dlz_bucket_name=dlz_bucket, region=region
        )

    def _get_prefix(self, domain_name, dataset_name, user, file_type, upload_date=None):
        """
        returns the prefix for data to read
        :param domain_name: domain name for dataset
        :param dataset_name: dataset name
        :param user: UserId who has permission to upload data
        :param file_type: Type of data in the dataset. For ex., csv, pdf, png
        :param upload_date: date to use to upload the data
        :return:
        """

        full_s3_path = "/".join(
            ["s3:/", self.bucket_name, domain_name, dataset_name, ""]
        )

        if upload_date:
            _upload_date = str(int(upload_date))
        else:
            _upload_date = str(int(time.time()))

        _prefix = (
            full_s3_path
            + "upload_date="
            + _upload_date
            + "/"
            + user
            + "/"
            + file_type
            + "/"
        )

        return _upload_date, _prefix

    def get_glue_df_with_prefix_partition(self, df, upload_date, user, file_type):
        # Add upload_date to the data
        upload_date_col_value = "/".join([upload_date, user, file_type, ""])
        data = df.withColumn("upload_date", lit(upload_date_col_value))
        glue_df = DynamicFrame.fromDF(data, glue_context, "glue_df")
        return glue_df

    # pylint: disable=too-many-arguments, too-many-locals
    def write_csv_data(
        self,
        data,
        domain_name,
        dataset_name,
        user,
        header=False,
        file_type="csv",
        quote=True,
        delimiter=",",
        upload_date=None,
        full_reload=False,
        path=None,
        reload_wait=30,
        partition_keys: list = None,
        quoteAll=True,
        **kwargs
    ):
        """
        Write data to lz bucket

        :param data: spark dataframe of data
        :param domain_name: domain name for dataset
        :param dataset_name: dataset name
        :param user: username with write access to dataset
        :param header: True if you want to save file with header. Default: False
        :param file_type: file type for dataset
        :param quote: True if you want to save you data with quoted character. Default: True
        :param delimiter: The delimiter to use while storing file, Default: ,
        :param upload_date: Current timestamp from time.time(). If not supplied, then cuurent timestamp is used
        :param full_reload: True if the table type is of reload type, Default: False
        :param path: (Optional)Path where data is stored. Implicit creation of path will be ignored
        :param reload_wait: Time to wait before trigger reload is seconds. Default: 30
        :param partition_keys: List of column name to be used as partitions
        :param quoteAll: param for quoting the data, Default True.
        :param kwargs: Optional arguments available for pyspark write

        :return: dict with exitcode and message

        >>> writer = Write("lz_bucket")
        >>> response = writer.write_csv_data(spark_df, "testdomain", "testdataset", user="userid", file_type="csv")
        >>> print(response)
        >>> {
          "exitcode": 0,
          "message": "This is success message"
          }
        """

        try:
            self._logger.info(
                "In Write.write_csv_data, Writing csv data to dataset {0}.{1}".format(
                    domain_name, dataset_name
                )
            )
            if path:
                _prefix = path
            else:
                if not partition_keys:
                    upload_date, _prefix = self._get_prefix(
                        domain_name, dataset_name, user, file_type, upload_date
                    )
                else:
                    if upload_date:
                        upload_date = str(int(upload_date))
                    else:
                        upload_date = str(int(time.time()))
                    _prefix = "/".join(
                        ["s3:/", self.bucket_name, domain_name, dataset_name, ""]
                    )

            if partition_keys:
                self._logger.info(
                    "In Write.write_csv_data, Saving the data using partition_keys {0}".format(
                        partition_keys
                    )
                )

                glue_df = self.get_glue_df_with_prefix_partition(
                    data, upload_date, user, file_type
                )
                partition_keys.append("upload_date")

                datasink = glue_context.write_dynamic_frame.from_options(
                    frame=glue_df,
                    connection_type="s3",
                    connection_options={
                        "path": _prefix,
                        "partitionKeys": partition_keys,
                    },
                    format="csv",
                    format_options={
                        "separator": delimiter,
                        "withHeader": header,
                        **kwargs,
                    },
                    transformation_ctx="datasink",
                )
            elif quote:
                data.write.csv(
                    _prefix,
                    quote='"',
                    quoteAll=quoteAll,
                    header=header,
                    sep=delimiter,
                    **kwargs
                )
            else:
                data.write.csv(_prefix, header=header, sep=delimiter, **kwargs)

            if full_reload:
                if partition_keys:
                    # TODO: Find a fix to avoid sleep
                    self._logger.info(
                        "In Write.write_csv_data, Sleeping {0} seconds".format(
                            reload_wait
                        )
                    )
                    time.sleep(reload_wait)
                    domain_dataset_prefix = "/".join([domain_name, dataset_name, ""])
                    s3_keys = awshelper.get_object_names(
                        self.bucket_name, domain_dataset_prefix, self.region
                    )
                    s3_partition_prefixes = list(
                        {"/".join(s3_key.split("/")[:-1]) for s3_key in s3_keys}
                    )
                    self._logger.info(
                        "In Write.write_csv_data, Saving _SUCCESS file under partitions {0}".format(
                            partition_keys
                        )
                    )
                    for key in s3_partition_prefixes:
                        self.send_success_file(
                            domain_name, dataset_name, user, file_type, prefix=key
                        )
                else:
                    result = bool_retry(5, 5, True)(self.is_epoch_dir_exists)(
                        bucket_name=self.bucket_name,
                        domain_name=domain_name,
                        dataset_name=dataset_name,
                        upload_date=upload_date,
                        path=path,
                        region=self.region,
                    )
                    if result:
                        self._logger.info(
                            "In Write.write_csv_data, Writing _SUCCESS file to dataset {0}.{1}".format(
                                domain_name, dataset_name
                            )
                        )
                        # TODO: Find a fix to avoid sleep
                        time.sleep(reload_wait)
                        self.send_success_file(
                            domain_name, dataset_name, user, file_type, prefix=_prefix
                        )
                        # super(Write, self).send_success_file(domain_name, dataset_name, user, file_type)
                    else:
                        raise Exception(
                            "Failed to upload _SUCCESS file to trigger reload. Please trigger from UI."
                        )

            response = {"exitcode": 0, "message": "Successfully saved data to s3."}
        except Exception as ex:
            response = {"exitcode": 1, "message": ex}
        return response

    def write_parquet(
        self,
        data,
        domain_name,
        dataset_name,
        user,
        upload_date=None,
        file_type="parquet",
        full_reload=False,
        path=None,
        reload_wait=30,
        partition_keys: list = None,
        **kwargs
    ):
        """
        Write data to lz bucket

        :param data: spark dataframe of data
        :param domain_name: domain name for dataset
        :param dataset_name: dataset name
        :param user: username with write access to dataset
        :param upload_date: Current timestamp from time.time(). If not supplied, then cuurent timestamp is used
        :param file_type: file type for dataset, Default: parquet
        :param full_reload: True if the table type is of reload type, Default: False
        :param path: (Optional)Path where data is stored. Implicit creation of path will be ignored
        :param reload_wait: Time to wait before trigger reload is seconds. Default: 30
        :param partition_keys: List of column name to be used as partitions
        :param kwargs: Optional arguments available for pyspark write

        :return: dict with exitcode and message

        >>> writer = Write("lz_bucket")
        >>> response = writer.write_parquet(spark_df, "testdomain", "testdataset", user="userid")
        >>> print(response)
        >>> {
          "exitcode": 0,
          "message": "This is success message"
          }
        """

        try:
            self._logger.info(
                "In Write.write_parquet, Writing parquet data to dataset {0}.{1}".format(
                    domain_name, dataset_name
                )
            )

            if path:
                _prefix = path
            else:
                if not partition_keys:
                    upload_date, _prefix = self._get_prefix(
                        domain_name, dataset_name, user, file_type, upload_date
                    )
                else:
                    if upload_date:
                        upload_date = str(int(upload_date))
                    else:
                        upload_date = str(int(time.time()))
                    _prefix = "/".join(
                        ["s3:/", self.bucket_name, domain_name, dataset_name, ""]
                    )

            if partition_keys:
                self._logger.info(
                    "In Write.write_csv_data, Saving the data using partition_keys {0}".format(
                        partition_keys
                    )
                )

                glue_df = self.get_glue_df_with_prefix_partition(
                    data, upload_date, user, file_type
                )
                partition_keys.append("upload_date")

                datasink = glue_context.write_dynamic_frame.from_options(
                    frame=glue_df,
                    connection_type="s3",
                    connection_options={
                        "path": _prefix,
                        "partitionKeys": partition_keys,
                    },
                    format="parquet",
                    format_options={**kwargs},
                    transformation_ctx="datasink",
                )
            else:
                data.write.parquet(_prefix, **kwargs)

            if full_reload:
                if partition_keys:
                    # TODO: Find a fix to avoid sleep
                    self._logger.info(
                        "In Write.write_csv_data, Sleeping {0} seconds".format(
                            reload_wait
                        )
                    )
                    time.sleep(reload_wait)
                    domain_dataset_prefix = "/".join([domain_name, dataset_name, ""])
                    s3_keys = awshelper.get_object_names(
                        self.bucket_name, domain_dataset_prefix, self.region
                    )
                    s3_partition_prefixes = list(
                        {"/".join(s3_key.split("/")[:-1]) for s3_key in s3_keys}
                    )
                    self._logger.info(
                        "In Write.write_csv_data, Saving _SUCCESS file under partitions {0}".format(
                            partition_keys
                        )
                    )
                    for key in s3_partition_prefixes:
                        self.send_success_file(
                            domain_name, dataset_name, user, file_type, prefix=key
                        )
                else:
                    result = bool_retry(5, 5, True)(self.is_epoch_dir_exists)(
                        bucket_name=self.bucket_name,
                        domain_name=domain_name,
                        dataset_name=dataset_name,
                        upload_date=upload_date,
                        path=path,
                        region=self.region,
                    )
                    if result:
                        self._logger.info(
                            "In Write.write_parquet, Writing _SUCCESS file to dataset {0}.{1}".format(
                                domain_name, dataset_name
                            )
                        )
                        # TODO: Find a fix to avoid sleep
                        time.sleep(reload_wait)
                        self.send_success_file(
                            domain_name, dataset_name, user, file_type, prefix=_prefix
                        )
                        # super(Write, self).send_success_file(domain_name, dataset_name, user, file_type)
                    else:
                        raise Exception(
                            "Failed to upload _SUCCESS file to trigger reload. Please trigger from UI."
                        )

            response = {"exitcode": 0, "message": "Successfully saved data to s3."}
        except Exception as ex:
            response = {"exitcode": 1, "message": ex}
        return response

    def write_json(
        self,
        data,
        domain_name,
        dataset_name,
        user,
        upload_date=None,
        file_type="others",
        full_reload=False,
        path=None,
        reload_wait=30,
        **json_kwargs
    ):
        """
        Write data to lz bucket

        :param data: spark dataframe of data
        :param domain_name: domain name for dataset
        :param dataset_name: dataset name
        :param user: username with write access to dataset
        :param upload_date: Current timestamp from time.time(). If not supplied, then cuurent timestamp is used
        :param file_type: file type for dataset, Default: others
        :param full_reload: True if the table type is of reload type, Default: False
        :param path: (Optional)Path where data is stored. Implicit creation of path will be ignored
        :param json_kwargs: Optional arguments available for pyspark write
        :param reload_wait: Time to wait before trigger reload is seconds. Default: 30

        :return: dict with exitcode and message

        >>> writer = Write("lz_bucket")
        >>> response = writer.write_json(spark_df, "testdomain", "testdataset", user="userid")
        >>> print(response)
        >>> {
          "exitcode": 0,
          "message": "This is success message"
          }
        """

        try:
            self._logger.info(
                "In Write.write_json, Writing json data to dataset {0}.{1}".format(
                    domain_name, dataset_name
                )
            )
            if path:
                _prefix = path
            else:
                upload_date, _prefix = self._get_prefix(
                    domain_name, dataset_name, user, file_type, upload_date
                )

            data.write.json(_prefix, **json_kwargs)

            if full_reload:
                result = bool_retry(5, 5, True)(self.is_epoch_dir_exists)(
                    bucket_name=self.bucket_name,
                    domain_name=domain_name,
                    dataset_name=dataset_name,
                    upload_date=upload_date,
                    path=path,
                    region=self.region,
                )
                if result:
                    self._logger.info(
                        "In Write.write_parquet, Writing _SUCCESS file to dataset {0}.{1}".format(
                            domain_name, dataset_name
                        )
                    )
                    # TODO: Find a fix to avoid sleep
                    time.sleep(reload_wait)
                    self.send_success_file(
                        domain_name, dataset_name, user, file_type, prefix=_prefix
                    )
                    # super(Write, self).send_success_file(domain_name, dataset_name, user, file_type)
                else:
                    raise Exception(
                        "Failed to upload _SUCCESS file to trigger reload. Please trigger from UI."
                    )

            response = {"exitcode": 0, "message": "Successfully saved data to s3."}
        except Exception as ex:
            response = {"exitcode": 1, "message": ex}
        return response

    def __write_avro_data(
        self,
        data,
        domain_name,
        dataset_name,
        user,
        file_type="csv",
        quote=True,
        upload_date=None,
        path=None,
    ):
        """
        Write data to lz bucket in avro format

        :param data: spark dataframe of data
        :param domain_name: domain name for dataset
        :param dataset_name: dataset name
        :param user: username with write access to dataset
        :param file_type: file type for dataset
        :param quote: True if you want to save you data with quoted character. Default: True
        :param upload_date: Current timestamp from time.time(). If not supplied, then cuurent timestamp is used
        :param path: (Optional)Path where data is stored. Implicit creation of path will be ignored
        :return:
        """

        try:
            if path:
                _prefix = path
            else:
                upload_date, _prefix = self._get_prefix(
                    domain_name, dataset_name, user, file_type, upload_date
                )

            if quote:
                data.write.format("avro").save(_prefix)
            else:
                data.write.format("avro").save(_prefix)
            response = {
                "exitcode": 0,
                "message": "Successfully saved data to s3 in avro format.",
            }
        except Exception as ex:
            response = {"exitcode": 1, "message": ex}
        return response


class GlueWrite(WriteUtil, DataLandingZoneUtil):
    """
    Class to write data using GlueContext
    """

    def __init__(self, bucket_name, glue_context, region=None, logger=None):
        """
        Initialize the Write object

        :param bucket_name: Bucket name
        :param glue_context: GlueContext

        >>> writer = Write("lz_bucket", glue_context)
        """

        if region:
            self.s3_resource = boto3.resource("s3", region)
        else:
            self.s3_resource = boto3.resource("s3")
        self.region = region
        self.glue_context = glue_context
        self.bucket = self.s3_resource.Bucket(bucket_name)
        self.bucket_name = bucket_name
        self._logger = (
            logger if logger else Log4j(glue_context.spark_session).get_logger()
        )
        WriteUtil.__init__(self, bucket_name, region)
        dlz_bucket = "-".join(bucket_name.split("-")[0:-1] + ["dlz"])
        DataLandingZoneUtil.__init__(
            self, lz_bucket_name=bucket_name, dlz_bucket_name=dlz_bucket, region=region
        )

    def _get_prefix(self, domain_name, dataset_name, user, file_type, upload_date=None):
        """
        returns the prefix for data to read
        :param domain_name: domain name for dataset
        :param dataset_name: dataset name
        :param user: UserId who has permission to upload data
        :param file_type: Type of data in the dataset. For ex., csv, pdf, png
        :param upload_date: date to use to upload the data
        :return:
        """

        full_s3_path = "/".join(
            ["s3:/", self.bucket_name, domain_name, dataset_name, ""]
        )

        if upload_date:
            _upload_date = str(int(upload_date))
        else:
            _upload_date = str(int(time.time()))

        _prefix = (
            full_s3_path
            + "upload_date="
            + _upload_date
            + "/"
            + user
            + "/"
            + file_type
            + "/"
        )

        return _upload_date, _prefix

    def get_glue_df_with_prefix_partition(self, df, upload_date, user, file_type):
        # Add upload_date to the data
        upload_date_col_value = "/".join([upload_date, user, file_type, ""])
        data = df.withColumn("upload_date", lit(upload_date_col_value))
        glue_df = DynamicFrame.fromDF(data, glue_context, "glue_df")
        return glue_df

    # pylint: disable=too-many-arguments, too-many-locals
    def write_csv_data(
        self,
        data,
        domain_name,
        dataset_name,
        user,
        header=False,
        file_type="csv",
        quote=True,
        delimiter=",",
        upload_date=None,
        full_reload=False,
        path=None,
        reload_wait=30,
        partition_keys: list = None,
        quoteAll=True,
        **kwargs
    ):
        """
        Write data to lz bucket

        :param data: spark dataframe of data
        :param domain_name: domain name for dataset
        :param dataset_name: dataset name
        :param user: username with write access to dataset
        :param header: True if you want to save file with header. Default: False
        :param file_type: file type for dataset
        :param quote: True if you want to save you data with quoted character. Default: True
        :param delimiter: The delimiter to use while storing file, Default: ,
        :param upload_date: Current timestamp from time.time(). If not supplied, then cuurent timestamp is used
        :param full_reload: True if the table type is of reload type, Default: False
        :param path: (Optional)Path where data is stored. Implicit creation of path will be ignored
        :param reload_wait: Time to wait before trigger reload is seconds. Default: 30
        :param partition_keys: List of column name to be used as partitions
        :param quoteAll: param for quoting the data, Default True.
        :param kwargs: Optional arguments available for pyspark write

        :return: dict with exitcode and message

        >>> writer = Write("lz_bucket")
        >>> response = writer.write_csv_data(spark_df, "testdomain", "testdataset", user="userid", file_type="csv")
        >>> print(response)
        >>> {
          "exitcode": 0,
          "message": "This is success message"
          }
        """

        try:
            self._logger.info(
                "In Write.write_csv_data, Writing csv data to dataset {0}.{1}".format(
                    domain_name, dataset_name
                )
            )
            if path:
                _prefix = path
            else:
                if not partition_keys:
                    upload_date, _prefix = self._get_prefix(
                        domain_name, dataset_name, user, file_type, upload_date
                    )
                else:
                    if upload_date:
                        upload_date = str(int(upload_date))
                    else:
                        upload_date = str(int(time.time()))
                    _prefix = "/".join(
                        ["s3:/", self.bucket_name, domain_name, dataset_name, ""]
                    )

            if partition_keys:
                self._logger.info(
                    "In Write.write_csv_data, Saving the data using partition_keys {0}".format(
                        partition_keys
                    )
                )

                glue_df = self.get_glue_df_with_prefix_partition(
                    data, upload_date, user, file_type
                )
                partition_keys.append("upload_date")

                datasink = glue_context.write_dynamic_frame.from_options(
                    frame=glue_df,
                    connection_type="s3",
                    connection_options={
                        "path": _prefix,
                        "partitionKeys": partition_keys,
                    },
                    format="csv",
                    format_options={
                        "separator": delimiter,
                        "withHeader": header,
                        **kwargs,
                    },
                    transformation_ctx="datasink",
                )
            else:
                glue_df = (
                    DynamicFrame.fromDF(data, self.glue_context, "glue_df")
                    if isinstance(data, DataFrame)
                    else data
                )

                datasink = self.glue_context.write_dynamic_frame.from_options(
                    frame=glue_df,
                    connection_type="s3",
                    connection_options={"path": _prefix},
                    format="csv",
                    format_options={
                        "separator": delimiter,
                        "withHeader": header,
                        **kwargs,
                    },
                    transformation_ctx="datasink",
                )

            if full_reload:
                if partition_keys:
                    # TODO: Find a fix to avoid sleep
                    self._logger.info(
                        "In Write.write_csv_data, Sleeping {0} seconds".format(
                            reload_wait
                        )
                    )
                    time.sleep(reload_wait)
                    domain_dataset_prefix = "/".join([domain_name, dataset_name, ""])
                    s3_keys = awshelper.get_object_names(
                        self.bucket_name, domain_dataset_prefix, self.region
                    )
                    s3_partition_prefixes = list(
                        {"/".join(s3_key.split("/")[:-1]) for s3_key in s3_keys}
                    )
                    self._logger.info(
                        "In Write.write_csv_data, Saving _SUCCESS file under partitions {0}".format(
                            partition_keys
                        )
                    )
                    for key in s3_partition_prefixes:
                        self.send_success_file(
                            domain_name, dataset_name, user, file_type, prefix=key
                        )
                else:
                    result = bool_retry(5, 5, True)(self.is_epoch_dir_exists)(
                        bucket_name=self.bucket_name,
                        domain_name=domain_name,
                        dataset_name=dataset_name,
                        upload_date=upload_date,
                        path=path,
                        region=self.region,
                    )
                    if result:
                        self._logger.info(
                            "In Write.write_csv_data, Writing _SUCCESS file to dataset {0}.{1}".format(
                                domain_name, dataset_name
                            )
                        )
                        # TODO: Find a fix to avoid sleep
                        time.sleep(reload_wait)
                        self.send_success_file(
                            domain_name, dataset_name, user, file_type, prefix=_prefix
                        )
                        # super(Write, self).send_success_file(domain_name, dataset_name, user, file_type)
                    else:
                        raise Exception(
                            "Failed to upload _SUCCESS file to trigger reload. Please trigger from UI."
                        )

            response = {"exitcode": 0, "message": "Successfully saved data to s3."}
        except Exception as ex:
            response = {"exitcode": 1, "message": ex}
        return response

    def write_parquet(
        self,
        data,
        domain_name,
        dataset_name,
        user,
        upload_date=None,
        file_type="parquet",
        full_reload=False,
        path=None,
        reload_wait=30,
        partition_keys: list = None,
        format="glueparquet",
        **kwargs
    ):
        """
        Write data to lz bucket

        :param data: spark dataframe of data
        :param domain_name: domain name for dataset
        :param dataset_name: dataset name
        :param user: username with write access to dataset
        :param upload_date: Current timestamp from time.time(). If not supplied, then cuurent timestamp is used
        :param file_type: file type for dataset, Default: parquet
        :param full_reload: True if the table type is of reload type, Default: False
        :param path: (Optional)Path where data is stored. Implicit creation of path will be ignored
        :param reload_wait: Time to wait before trigger reload is seconds. Default: 30
        :param partition_keys: List of column name to be used as partitions
        :param format: glueparquet or parquet
        :param kwargs: Optional arguments available for pyspark write

        :return: dict with exitcode and message

        >>> writer = Write("lz_bucket")
        >>> response = writer.write_parquet(data, "testdomain", "testdataset", user="userid")
        >>> print(response)
        >>> {
          "exitcode": 0,
          "message": "This is success message"
          }
        """

        try:
            self._logger.info(
                "In Write.write_parquet, Writing parquet data to dataset {0}.{1}".format(
                    domain_name, dataset_name
                )
            )

            if path:
                _prefix = path
            else:
                if not partition_keys:
                    upload_date, _prefix = self._get_prefix(
                        domain_name, dataset_name, user, file_type, upload_date
                    )
                else:
                    if upload_date:
                        upload_date = str(int(upload_date))
                    else:
                        upload_date = str(int(time.time()))
                    _prefix = "/".join(
                        ["s3:/", self.bucket_name, domain_name, dataset_name, ""]
                    )

            try:
                if partition_keys:
                    self._logger.info(
                        "In Write.write_csv_data, Saving the data using partition_keys {0}".format(
                            partition_keys
                        )
                    )

                    glue_df = self.get_glue_df_with_prefix_partition(
                        data, upload_date, user, file_type
                    )
                    partition_keys.append("upload_date")

                    datasink = glue_context.write_dynamic_frame.from_options(
                        frame=glue_df,
                        connection_type="s3",
                        connection_options={
                            "path": _prefix,
                            "partitionKeys": partition_keys,
                        },
                        format=format,
                        format_options={**kwargs},
                        transformation_ctx="datasink",
                    )
                else:
                    glue_df = (
                        DynamicFrame.fromDF(data, self.glue_context, "glue_df")
                        if isinstance(data, DataFrame)
                        else data
                    )

                    datasink = glue_context.write_dynamic_frame.from_options(
                        frame=glue_df,
                        connection_type="s3",
                        connection_options={"path": _prefix},
                        format=format,
                        format_options={**kwargs},
                        transformation_ctx="datasink",
                    )
            except Py4JJavaError as p4jerr:
                self._logger.error(
                    "In Write.write_parquet, Py4JJavaError error occurred while saving parquet data."
                )
                result = bool_retry(5, 5, True)(self.is_epoch_dir_exists)(
                    bucket_name=self.bucket_name,
                    domain_name=domain_name,
                    dataset_name=dataset_name,
                    upload_date=upload_date,
                    path=path,
                    region=self.region,
                )
                if result:
                    self._logger.info(
                        "In Write.write_parquet, Successfully saved data to s3 with exception."
                    )
                else:
                    raise p4jerr

            if full_reload:
                if partition_keys:
                    # TODO: Find a fix to avoid sleep
                    self._logger.info(
                        "In Write.write_csv_data, Sleeping {0} seconds".format(
                            reload_wait
                        )
                    )
                    time.sleep(reload_wait)
                    domain_dataset_prefix = "/".join([domain_name, dataset_name, ""])
                    s3_keys = awshelper.get_object_names(
                        self.bucket_name, domain_dataset_prefix, self.region
                    )
                    s3_partition_prefixes = list(
                        {"/".join(s3_key.split("/")[:-1]) for s3_key in s3_keys}
                    )
                    self._logger.info(
                        "In Write.write_csv_data, Saving _SUCCESS file under partitions {0}".format(
                            partition_keys
                        )
                    )
                    for key in s3_partition_prefixes:
                        self.send_success_file(
                            domain_name, dataset_name, user, file_type, prefix=key
                        )
                else:
                    result = bool_retry(5, 5, True)(self.is_epoch_dir_exists)(
                        bucket_name=self.bucket_name,
                        domain_name=domain_name,
                        dataset_name=dataset_name,
                        upload_date=upload_date,
                        path=path,
                        region=self.region,
                    )
                    if result:
                        self._logger.info(
                            "In Write.write_parquet, Writing _SUCCESS file to dataset {0}.{1}".format(
                                domain_name, dataset_name
                            )
                        )
                        # TODO: Find a fix to avoid sleep
                        time.sleep(reload_wait)
                        self.send_success_file(
                            domain_name, dataset_name, user, file_type, prefix=_prefix
                        )
                        # super(Write, self).send_success_file(domain_name, dataset_name, user, file_type)
                    else:
                        raise Exception(
                            "Failed to upload _SUCCESS file to trigger reload. Please trigger from UI."
                        )

            response = {"exitcode": 0, "message": "Successfully saved data to s3."}
        except Exception as ex:
            response = {"exitcode": 1, "message": ex}
        return response

    def write_json(
        self,
        data,
        domain_name,
        dataset_name,
        user,
        upload_date=None,
        file_type="others",
        full_reload=False,
        path=None,
        reload_wait=30,
        **json_kwargs
    ):
        """
        Write data to lz bucket

        :param data: spark dataframe of data
        :param domain_name: domain name for dataset
        :param dataset_name: dataset name
        :param user: username with write access to dataset
        :param upload_date: Current timestamp from time.time(). If not supplied, then cuurent timestamp is used
        :param file_type: file type for dataset, Default: others
        :param full_reload: True if the table type is of reload type, Default: False
        :param path: (Optional)Path where data is stored. Implicit creation of path will be ignored
        :param json_kwargs: Optional arguments available for pyspark write
        :param reload_wait: Time to wait before trigger reload is seconds. Default: 30

        :return: dict with exitcode and message

        >>> writer = Write("lz_bucket")
        >>> response = writer.write_json(data, "testdomain", "testdataset", user="userid")
        >>> print(response)
        >>> {
          "exitcode": 0,
          "message": "This is success message"
          }
        """

        try:
            self._logger.info(
                "In Write.write_json, Writing json data to dataset {0}.{1}".format(
                    domain_name, dataset_name
                )
            )
            if path:
                _prefix = path
            else:
                upload_date, _prefix = self._get_prefix(
                    domain_name, dataset_name, user, file_type, upload_date
                )

            glue_df = (
                DynamicFrame.fromDF(data, self.glue_context, "glue_df")
                if isinstance(data, DataFrame)
                else data
            )

            datasink = glue_context.write_dynamic_frame.from_options(
                frame=glue_df,
                connection_type="s3",
                connection_options={"path": _prefix},
                format="json",
                format_options={**json_kwargs},
                transformation_ctx="datasink",
            )

            if full_reload:
                result = bool_retry(5, 5, True)(self.is_epoch_dir_exists)(
                    bucket_name=self.bucket_name,
                    domain_name=domain_name,
                    dataset_name=dataset_name,
                    upload_date=upload_date,
                    path=path,
                    region=self.region,
                )
                if result:
                    self._logger.info(
                        "In Write.write_parquet, Writing _SUCCESS file to dataset {0}.{1}".format(
                            domain_name, dataset_name
                        )
                    )
                    # TODO: Find a fix to avoid sleep
                    time.sleep(reload_wait)
                    self.send_success_file(
                        domain_name, dataset_name, user, file_type, prefix=_prefix
                    )
                    # super(Write, self).send_success_file(domain_name, dataset_name, user, file_type)
                else:
                    raise Exception(
                        "Failed to upload _SUCCESS file to trigger reload. Please trigger from UI."
                    )

            response = {"exitcode": 0, "message": "Successfully saved data to s3."}
        except Exception as ex:
            response = {"exitcode": 1, "message": ex}
        return response


class Write:
    """
    Class to write data from Amorphic
    """

    def __init__(self, bucket_name, spark, region=None, logger=None):
        """
        Initialize the Write object

        :param bucket_name: Bucket name
        :param spark: SparkContext

        >>> writer = Write("lz_bucket", spark_object)
        """

        if region:
            self.s3_resource = boto3.resource("s3", region)
        else:
            self.s3_resource = boto3.resource("s3")
        self.region = region
        self.bucket = self.s3_resource.Bucket(bucket_name)
        self.bucket_name = bucket_name

        if isinstance(spark, GlueContext):
            self.instance = GlueWrite(bucket_name, spark, logger=logger)
        else:
            self.instance = SparkWrite(bucket_name, spark, logger=logger)

    def __getattr__(self, name):
        return self.instance.__getattribute__(name)
