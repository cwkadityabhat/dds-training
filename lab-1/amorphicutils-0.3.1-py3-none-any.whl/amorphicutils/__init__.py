"""
Contains version number for package
"""

# Version
__version__ = "0.3.1"
