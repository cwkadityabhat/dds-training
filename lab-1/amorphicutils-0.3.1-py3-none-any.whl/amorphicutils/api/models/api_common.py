"""
Module contains common functionalities across all the api models
"""

from amorphicutils.amorphiclogging import Log4j
from amorphicutils.api.utils import generate_json_reponse


class ApiCommon:
    """
    Common class across API models
    """

    def __init__(self, api_wrapper):
        """
        Initialize ApiCommon class

        :param api_wrapper:
        """
        self.api_wrapper = api_wrapper
        self.log4j = Log4j()
        self._logger = self.log4j.get_logger()

    def get_resource_id(self, resource_type, resource_name):
        """
        Returns resource id

        :param resource_type: Type of resource
        :param resource_name: Name of the resource
        :return:
        """

        self._logger.info(
            "In {name}, getting ID for resource type {type} with name {resource}".format(
                name=__name__, type=resource_type, resource=resource_name
            )
        )

        if resource_type == "datasets":
            _operation = "resourcetype_datasets"
        elif resource_type == "jobs":
            _operation = "resourcetype_jobs"
        else:
            self._logger.error(
                "In {name}, resource type {type} in not defined.".format(
                    name=__name__, type=resource_type
                )
            )
            raise Exception(
                "In {name}, resource type {type} in not defined.".format(
                    name=__name__, type=resource_type
                )
            )

        resource_details_response = self.api_wrapper.make_request(
            operation=_operation, fields=resource_name
        )

        return generate_json_reponse(resource_details_response)
