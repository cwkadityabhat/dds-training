"""
Module to perform bookmarking in Amorphic
"""

import json
import time
from amorphicutils import awshelper


class KeyUnavailableException(ValueError):
    """raise when data is unavailable in state data"""


class ObjectNotStateDataException(ValueError):
    """raise when data is not in bytes"""


class ObjectNotDictException(ValueError):
    """raise when object is not dict type"""


class ObjectNotBytesException(ValueError):
    """raise when object not bytes type"""


class StateData:
    """
    Class to store the state data. It stores the data as dictionary.
    """

    def __init__(self):
        """
        Initialize the StateData class

        >>> state_data = StateData()
        """

        self.data = {}

    def __str__(self):
        """
        Returns the data in string format

        :return: string of data
        """

        return json.dumps(self.data)

    def add_element(self, key, value):
        """
        Add element to the state data

        :param key: key of the state data
        :param value: value of the state data
        :return:

        >>> state_data = StateData()
        >>> state_data.add_element("DatasetId", {"epoch_time": 156234987})
        """

        self.data[key] = value

    def remove_element(self, key):
        """
        Removes the element from state data

        :param key: key of the state data
        :return:

        >>> state_data = StateData()
        >>> state_data.remove_element("DatasetId")
        """

        del self.data[key]

    def to_bytes(self):
        """
        Returns the state data in bytes format

        :return: bytes of state data

        >>> state_data.to_bytes()
        """

        # return bytes(json.dumps(self.data), encoding='utf-8')
        return json.dumps(self.data).encode("utf-8")

    def __getitem__(self, key):
        return self.data.get(key, None)

    def from_bytes(self, data):
        """
        Load the dict of data into state data class

        :param data: dict of data to be loaded
        :return:

        >>> state_data = StateData()
        >>> state_data.from_bytes({ "DatasetId": { "epoch_time": 156234678}})
        """
        if isinstance(data, bytes):
            json_obj = json.loads(data)
            if isinstance(json_obj, dict):
                for key, value in json_obj.items():
                    self.add_element(key, value)
            else:
                raise ObjectNotDictException
        else:
            raise ObjectNotBytesException

    def reset(self):
        """
        Resets the data of StateData class
        :return:
        """

        self.data = {}


class StateStore:
    """
    Store the state of the amorphic etl jobs
    """

    new_prefix = ""

    def __init__(
        self,
        lz_bucket_name,
        dlz_bucket_name,
        state_domain,
        state_dataset_name,
        username,
        file_type="others",
    ):
        """
        Initialize the StateStore class

        :param lz_bucket_name: bucket name of lz bucket
        :param dlz_bucket_name: bucket name of dlz bucket
        :param state_domain: domain of the state dataset
        :param state_dataset_name: dataset name of the state dataset
        :param username: user id of the user who has access to state data
        :param file_type: file type of the state dataset. Default: "others"

        >>> state_store = StateStore("lz_bucket", "dlz_bucket", "test_state_domian",
                                     "test_state_dataset", "test_user", "others")
        """
        self.lz_bucket_name = lz_bucket_name
        self.dlz_bucket_name = dlz_bucket_name
        self.state_domain = state_domain
        self.state_dataset_name = state_dataset_name
        self.prefix = self.state_domain + "/" + self.state_dataset_name + "/"
        self.job_name = ""
        self.username = username
        self.file_type = file_type

    def get_or_create(self, job_name):
        """
        Gets or create StateData instance

        :param job_name: name of the job name for which to maintain state
        :return: instance of StateData

        >>> state_store = StateStore("lz_bucket", "dlz_bucket", "test_state_domian",
                                     "test_state_dataset", "test_user", "others")
        >>> state_data = state_store.get_or_create("test_job")
        """
        key = awshelper.get_last_modified_object_key(
            self.dlz_bucket_name, self.prefix, job_name
        )
        if not key:
            # Create new file with running
            new_epoch = str(int(time.time()))
            state_data = StateData()
            self.new_prefix = self.prefix + "upload_date={0}/{1}/{2}/".format(
                new_epoch, self.username, self.file_type
            )
            new_key = self.new_prefix + "{0}".format(
                "_".join([job_name, new_epoch, "running.json"])
            )
            awshelper.put_object(self.lz_bucket_name, new_key, state_data.to_bytes())
        elif "completed" in key:
            state_data = StateData()
            # Create new file from completed with running
            new_epoch = str(int(time.time()))
            self.new_prefix = self.prefix + "upload_date={0}/{1}/{2}/".format(
                new_epoch, self.username, self.file_type
            )
            new_key = self.new_prefix + "{0}".format(
                "_".join([job_name, new_epoch, "running.json"])
            )
            awshelper.put_object(self.lz_bucket_name, new_key, state_data.to_bytes())
            # Get the last file with completed tag and populate state data
            s3_data = awshelper.get_object(self.dlz_bucket_name, key).read()
            if s3_data:
                state_data.from_bytes(s3_data)

        else:
            self.new_prefix = (
                "/".join(key.split("/")[:-1] + [self.username, self.file_type]) + "/"
            )
            # Get the last file with running tag
            s3_data = awshelper.get_object(self.dlz_bucket_name, key).read()
            state_data = StateData()
            if s3_data:
                state_data.from_bytes(s3_data)
        self.job_name = job_name
        return state_data

    def update(self, data):
        """
        Saves the file with running tag in s3

        :param data: StateData which will store data into s3
        :return:

        >>> state_store = StateStore("lz_bucket", "dlz_bucket", "test_state_domian",
                                     "test_state_dataset", "test_user", "others")
        >>> state_data = state_store.get_or_create("test_job")
        >>> state_data.add_element("DatasetId", {"epoch_time": 156234987})
        >>> state_store.update(state_data)
        """
        if isinstance(data, StateData):
            # Save to s3
            data_bytes = data.to_bytes()
            new_epoch = str(int(time.time()))
            new_key = self.new_prefix + "{0}".format(
                "_".join([self.job_name, new_epoch, "running.json"])
            )
            awshelper.put_object(self.lz_bucket_name, new_key, data_bytes)
        else:
            raise ObjectNotStateDataException

    def complete(self, data):
        """
        Saves the file with completed tag

        :param data: StateData which will store data into s3
        :return:

        >>> state_store = StateStore("lz_bucket", "dlz_bucket", "test_state_domian",
                                     "test_state_dataset", "test_user", "others")
        >>> state_data = state_store.get_or_create("test_job")
        >>> state_data.add_element("DatasetId", {"epoch_time": 156234987})
        >>> state_store.complete(state_data)
        """
        if isinstance(data, StateData):
            # Save to s3
            data_bytes = data.to_bytes()
            new_epoch = str(int(time.time()))
            new_key = self.new_prefix + "{0}".format(
                "_".join([self.job_name, new_epoch, "completed.json"])
            )
            awshelper.put_object(self.lz_bucket_name, new_key, data_bytes)
        else:
            raise ObjectNotStateDataException
