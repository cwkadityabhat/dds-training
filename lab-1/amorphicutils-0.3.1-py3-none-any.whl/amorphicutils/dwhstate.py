"""
Checks the state of data in data warehouse
"""

PARTITION_COL = "upload_time"


class DwhState:
    """
    Class to check if data is loaded ino datawarehouse (aurora or redshift)
    """

    @staticmethod
    def get_count_in_dwh(dwh_util, domain_name, dataset_name, upload_date):
        """
        Get the counts data based on upload_date

        :param dwh_util: instanace of datawarehouse util
        :param domain_name: domain of the dataset to query
        :param dataset_name: dataset to query
        :param upload_date: upload data to which to be queried
        :return:
        """
        _query = "SELECT COUNT(1) from {0}.{1} where {2}={3}".format(
            domain_name, dataset_name, PARTITION_COL, upload_date
        )
        dwh_util.run_query(_query)
        return dwh_util.fetch_one()

    def is_data_load_complete(
        self, dwh_util, domain_name, dataset_name, upload_date, data_count
    ):
        """
        Checks if the count in datawarehouse is equal to data_count

        :param dwh_util: datawarehouse util
        :param domain_name: domain name
        :param dataset_name: dataset name
        :param upload_date: upload_date to get count of data for that upload
        :param data_count: count against which to check if load is completed
        :return:
        """
        count_in_dwh = self.get_count_in_dwh(
            dwh_util, domain_name, dataset_name, upload_date
        )[0]
        if count_in_dwh == data_count:
            return True

        return False
